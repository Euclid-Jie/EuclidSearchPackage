# -*- coding: utf-8 -*-
# @Time    : 2023/3/28 11:43
# @Author  : Euclid-Jie
# @File    : Test.py
from src.EuclidSearchPackage import *
# Set_cookie('cookie.txt')
res = Get_single_weibo_data(mblogid='MrOtA75Fd')
print(res)

