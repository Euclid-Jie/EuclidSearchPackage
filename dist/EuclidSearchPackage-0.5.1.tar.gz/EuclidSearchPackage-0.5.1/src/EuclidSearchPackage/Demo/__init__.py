# -*- coding: utf-8 -*-
# @Time    : 2023/3/28 16:35
# @Author  : Euclid-Jie
# @File    : __init__.py.py

from .WeiboClassV2 import WeiboClassV2
from .WeiboClassV3 import WeiboClassV3
